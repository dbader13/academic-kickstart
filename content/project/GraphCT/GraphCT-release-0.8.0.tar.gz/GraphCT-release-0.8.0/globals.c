#include "globals.h"

double A, B, C, D;
int64_t SCALE;
int64_t numVertices;
int64_t numEdges;
int64_t maxWeight;
int64_t K4approx;
int64_t subGraphPathLength;

#ifndef GETOPT3_H
#define GETOPT3_H

#ifdef CYGWINNT
int getopt ( int argc, char *argv[], char *opts );
#endif

#endif
